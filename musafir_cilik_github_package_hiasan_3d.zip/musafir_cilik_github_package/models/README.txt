MODEL 3D SEBAGAI HIASAN SAHAJA

Letakkan fail model GLB di dalam folder bernama models.
Nama fail yang digunakan oleh nota:
- models/kereta.glb       (hiasan kecil pada halaman utama)
- models/warga-emas.glb  (hiasan pada kad Adab 6)
- models/bas.glb         (hiasan pada kad Adab 8)

Struktur repositori:
index.html
models/
  kereta.glb
  warga-emas.glb
  bas.glb

Model dipaparkan sebagai prop/hiasan statik. Murid tidak perlu menekan,
menyeret, memusing atau berinteraksi dengan model. Semua aktiviti asal nota
kekal seperti sedia ada. Pastikan lesen Poly Pizza membenarkan penggunaan
anda dan sertakan atribusi pencipta jika lesen memerlukannya.
